'use strict';
var MapFoodControllers = angular.module('ReachFoodControllers', []);

/*HomeCtrl:Checks internet connection and gets the current position of user*/
MapFoodControllers.controller('HomeCtrl', ['$ionicLoading', 'PopUp', '$scope', '$rootScope', '$location', function($ionicLoading, PopUp, $scope, $rootScope, $location) {

	
	$rootScope.home=0;
	 document.addEventListener("backbutton", onBackKeyDownPricing, false);

     function onBackKeyDownPricing(e) {
  
     	if($rootScope.home==1)
     	navigator.app.exitApp();
     }
     
    if (navigator.connection.type == 'none') {
        $ionicLoading.hide();
        var response = "Please check your internet connection and try again.";
        $scope.alert = PopUp.showAlert(response);
    } else {
        getPosition();
    }

    
    function getPosition() {
    	$rootScope.home=1;
         
    	 
        $ionicLoading.show({
            content: 'Loading',
            animation: 'fade-in',
            showBackdrop: true,
            maxWidth: 200,
            showDelay: 0
        });

        navigator.geolocation.getCurrentPosition(function(result) {
            $rootScope.position = result.coords;
            $location.path('/RestaurantList/restaurant');
            $scope.$apply();

        }, function(err) {
            if (err.code && err.code === 1) {
                var response = "Please check your internet connection and try again.";
                $scope.alert = PopUp.showAlert(response);
                $ionicLoading.hide();
            } else {
                var response = "Cannot access your location Service.Please enable it and try again";
                $scope.alert = PopUp.showAlert(response);
                $ionicLoading.hide();
            }
            console.log(err);
        }, {
            timeout: 10 * 1000
        });

    }
    $scope.TryAgain = function() {
       if (navigator.connection.type == 'none') {
            $ionicLoading.hide();
            var response = "Please check your internet connection and try again.";
            $scope.alert = PopUp.showAlert(response);
        } else {
            getPosition();
        }
       

    }
}]);

/*RestaurantListCtrl: Get restaurants using google places service api.*/
MapFoodControllers.controller('RestaurantListCtrl', ['$ionicLoading', '$scope', '$stateParams', 'PopUp', '$rootScope', '$ionicScrollDelegate', function($ionicLoading, $scope, $stateParams, PopUp, $rootScope, $ionicScrollDelegate) {

	$rootScope.home=0;
    $ionicLoading.hide();

    $scope.distances = [{
        meter: 804.672,
        name: 'Half Mile'
    }, {
        meter: 1609.34,
        name: '1 Mile'
    }, {
        meter: 3218.69,
        name: '2 Mile'
    }, {
        meter: 4828.03,
        name: '3 Mile'
    }, {
        meter: 6437.38,
        name: '4 Mile'
    }, {
        meter: 8046.72,
        name: '5 Mile'
    }, {
        meter: 16093.4,
        name: '5+ Mile'
    }];

    /*update radius*/
    $scope.update = function() {

        var request = {};
        request.location = new google.maps.LatLng(lat, lng);
        request.radius = this.selectedItem.meter;
        request.types = [$scope.restId];
        var service = new google.maps.places.PlacesService(document.createElement("div"));
        service.nearbySearch(request, callback);
    }

    /*Get Restaurant names*/
    $scope.getRestaurantsByName = function(str) {
        return User.getAllByName(str);

    };

    $scope.restId = $stateParams.restId;
    $rootScope.notHomepage = true;

    var lat = $rootScope.position.latitude;
    var lng = $rootScope.position.longitude;
    /*form a goolge places request and get reesults*/
    var request = {};
    request.location = new google.maps.LatLng(lat, lng);
    request.radius = 804.672;
    request.types = [$scope.restId];
    //request.rankBy= google.maps.places.RankBy.DISTANCE;

    var service = new google.maps.places.PlacesService(document.createElement("div"));
    service.nearbySearch(request, callback);

    function callback(result) {

        var matches = result.map(function(obj) {
            return {
                id: obj.id,
                reference: obj.reference,
                name: obj.name,
                address: obj.vicinity,
                icon: obj.icon,
                location: {
                    longitude: obj.geometry.location.lng(),
                    latitude: obj.geometry.location.lat()
                }
            };

        });
        $scope.matches = matches;
        $ionicScrollDelegate.resize();
        /*Display message if no results found*/
        if (matches.length === 0) {
            var response = "Could not locate any restaurant within the radius";
            $scope.alert = PopUp.showAlert(response);
        }
        $scope.$apply();
    }

}]);

/*RestaurantDetailCtrl:Displays details of the selected restaurant like:name,address,pricing,rating,phone,website.Also has features to email and map the location*/
MapFoodControllers.controller('RestaurantDetailCtrl', ['$scope', '$stateParams', '$rootScope', '$ionicSlideBoxDelegate', function($scope, $stateParams, $rootScope, $ionicSlideBoxDelegate) {
    $rootScope.notHomepage = true;
    $scope.placeId = $stateParams.placeId;

    /*Display website and googlemaps inapp*/
    function inAppBrowserbLoadStart(event) {

    }

    function inAppBrowserbLoadStop(event) {
        navigator.notification.activityStop();


    }

    function inAppBrowserbLoadError(event) {
        navigator.notification.activityStop();

    }
    $scope.Website = function(web) {
        var link = web;
        var inAppBrowserbRef = window.open(link, '_blank', 'location=yes');
        inAppBrowserbRef.addEventListener('loadstart', inAppBrowserbLoadStart);
        inAppBrowserbRef.addEventListener('loadstop', inAppBrowserbLoadStop);
        inAppBrowserbRef.addEventListener('loaderror', inAppBrowserbLoadError);
    };

    $scope.openGoogleMaps = function(lat, lng) {
        var link = "http://maps.google.com/maps?z=12&t=m&q=loc:" + lat + "+" + lng;
        var inAppBrowserbRef = window.open(link, '_blank', 'location=yes');
        inAppBrowserbRef.addEventListener('loadstart', inAppBrowserbLoadStart);
        inAppBrowserbRef.addEventListener('loadstop', inAppBrowserbLoadStop);
        inAppBrowserbRef.addEventListener('loaderror', inAppBrowserbLoadError);
    };

    /*Use places.PlacesService to get information like hours,rating,price,photos,etc*/
    var service = new google.maps.places.PlacesService(document.createElement("div"));
    service.getDetails({
        reference: $scope.placeId
    }, function(res) {
        console.dir(res);
        //modify res so we can use loc easier
        res.position = {
            longitude: res.geometry.location.lng(),
            latitude: res.geometry.location.lat()
        };

        if (res.opening_hours) {
            $scope.hasOpen = true;
        } else $scope.hasOpen = false;

        if (res.website) {
            $scope.haswebsite = true;
        } else $scope.website = false;

        if (res.rating) {
            $scope.hasrating = true;
            $scope.star = parseInt(res.rating);
            var remainder = 0;
            var fraction = res.rating.toString().split('.')[1];
            if (fraction > 4) {
                $scope.hasremainder = true;
                remainder = 1;
            } else {
                $scope.hasremainder = false;
                remainder = 0;
            }
            var x = $scope.star + remainder;

            $scope.nostar = 5 - x;


        } else $scope.hasrating = false;

        $scope.getTimes = function(n) {
            return new Array(n);
        };

        $scope.price = "";
        if (res.price_level) {
            if (res.price_level === 0) $scope.price = "$";
            if (res.price_level === 1) $scope.price = "$$";
            if (res.price_level === 2) $scope.price = "$$$";
            if (res.price_level === 3) $scope.price = "$$$$";
            if (res.price_level === 4) $scope.price = "$$$$$";
        }

        if (res.photos) {
            $scope.hasPhotos = true;
            for (var x = 0; x < res.photos.length; x++) {
                res.photos[x].url = res.photos[x].getUrl({
                    'maxWidth': 300,
                    'maxHeight': 300
                });
            }
        } else $scope.hasPhotos = false;

        $scope.place = res;
        $ionicSlideBoxDelegate.update();

        $scope.$apply();
    });

    /*email : emailComposer plugin*/
    $scope.composeEmail = function() {

        window.requestFileSystem(LocalFileSystem.PERSISTENT, 0, gotFS, fail);
    }

    function gotFS(fileSystem) {
        fileSystem.root.getFile("RestaurantDetails.html", {
            create: true
        }, gotFileEntry, fail);
    }
    var loc = "";

    function gotFileEntry(fileEntry) {
        loc = "";
        fileEntry.createWriter(gotFileWriter, fail);
        loc = fileEntry.fullPath;
        var length = loc.length;
        var platform = device.platform;
        if (platform == "iOS")
            loc = loc.substring(1, length);
        else
            loc = loc.substring(8, length);

    }

    function fail(error) {
        console.log(error.code);
    }

    /*Writes data in file to be sent as attachment.The reason for not including css in .css file is that it is very rare for a user to use this functionality and this avoids loading the css unless required*/
    function gotFileWriter(writer) {


        var link = "http://maps.google.com/maps?z=12&t=m&q=loc:" + $scope.place.position.latitude + "+" + $scope.place.position.longitude;

        var emaildata = document.getElementById('restcard').innerHTML;
        emaildata += '<p>Please check attachment for details</p>';

        var tabledata = '<body style="background-color:#808080 ;font-family: "Roboto", helvetica, arial, sans-serif;font-size: 16px;font-weight: 400;text-rendering: optimizeLegibility;">' +

            ' <table style="background: white;border-radius:3px; border-collapse: collapse; height: 320px; margin: auto; max-width: 600px; padding:5px;width: 100%; box-shadow: 0 5px 10px rgba(0, 0, 0, 0.1);animation: float 5s infinite;">' +
            '<thead>' +
            '<tr style="border-top: 1px solid #C1C3D1;border-bottom-: 1px solid #C1C3D1;color:#666B85;font-size:16px;font-weight:normal;text-shadow: 0 1px 1px rgba(256, 256, 256, 0.1);">' +
            ' <th class="text-left">Restaurant</th>' +
            '<th class="text-left">' + $scope.place.name + '</th>' +
            ' </tr>' +
            ' </thead>' +
            ' <tbody >' +
            '<tr style="border-top: 1px solid #C1C3D1;border-bottom-: 1px solid #C1C3D1;color:#666B85;font-size:16px;font-weight:normal;text-shadow: 0 1px 1px rgba(256, 256, 256, 0.1);">' +
            '<td style="text-align:left;padding:20px;text-align:left;vertical-align:middle;font-weight:300;font-size:18px;text-shadow: -1px -1px 1px rgba(0, 0, 0, 0.1);border-right: 1px solid #C1C3D1;">Address</td>' +
            '<td style="text-align:left;padding:20px;text-align:left;vertical-align:middle;font-weight:300;font-size:18px;text-shadow: -1px -1px 1px rgba(0, 0, 0, 0.1);border-right: 1px solid #C1C3D1;">' + $scope.place.formatted_address + '</td>' +
            '</tr>' +
            '<tr style="border-top: 1px solid #C1C3D1;border-bottom-: 1px solid #C1C3D1;color:#666B85;font-size:16px;font-weight:normal;text-shadow: 0 1px 1px rgba(256, 256, 256, 0.1);">' +
            '<td style="text-align:left;padding:20px;text-align:left;vertical-align:middle;font-weight:300;font-size:18px;text-shadow: -1px -1px 1px rgba(0, 0, 0, 0.1);border-right: 1px solid #C1C3D1;">Price Level</td>' +
            '<td style="text-align:left;padding:20px;text-align:left;vertical-align:middle;font-weight:300;font-size:18px;text-shadow: -1px -1px 1px rgba(0, 0, 0, 0.1);border-right: 1px solid #C1C3D1;">' + $scope.price + '</td>' +
            ' </tr>' +
            '<tr style="border-top: 1px solid #C1C3D1;border-bottom-: 1px solid #C1C3D1;color:#666B85;font-size:16px;font-weight:normal;text-shadow: 0 1px 1px rgba(256, 256, 256, 0.1);">' +
            '<td style="text-align:left;padding:20px;text-align:left;vertical-align:middle;font-weight:300;font-size:18px;text-shadow: -1px -1px 1px rgba(0, 0, 0, 0.1);border-right: 1px solid #C1C3D1;">Rating</td>' +
            '<td style="text-align:left;padding:20px;text-align:left;vertical-align:middle;font-weight:300;font-size:18px;text-shadow: -1px -1px 1px rgba(0, 0, 0, 0.1);border-right: 1px solid #C1C3D1;">' + $scope.place.rating + '</td>' +
            ' </tr>' +
            '<tr style="border-top: 1px solid #C1C3D1;border-bottom-: 1px solid #C1C3D1;color:#666B85;font-size:16px;font-weight:normal;text-shadow: 0 1px 1px rgba(256, 256, 256, 0.1);">' +
            '<td style="text-align:left;padding:20px;text-align:left;vertical-align:middle;font-weight:300;font-size:18px;text-shadow: -1px -1px 1px rgba(0, 0, 0, 0.1);border-right: 1px solid #C1C3D1;">Phone</td>' +
            '<td style="text-align:left;padding:20px;text-align:left;vertical-align:middle;font-weight:300;font-size:18px;text-shadow: -1px -1px 1px rgba(0, 0, 0, 0.1);border-right: 1px solid #C1C3D1;">' + $scope.place.formatted_phone_number + '</td>' +
            ' </tr>' +
            '<tr style="border-top: 1px solid #C1C3D1;border-bottom-: 1px solid #C1C3D1;color:#666B85;font-size:16px;font-weight:normal;text-shadow: 0 1px 1px rgba(256, 256, 256, 0.1);">' +
            '<td style="text-align:left;padding:20px;text-align:left;vertical-align:middle;font-weight:300;font-size:18px;text-shadow: -1px -1px 1px rgba(0, 0, 0, 0.1);border-right: 1px solid #C1C3D1;">Website</td>' +
            '<td style="text-align:left;padding:20px;text-align:left;vertical-align:middle;font-weight:300;font-size:18px;text-shadow: -1px -1px 1px rgba(0, 0, 0, 0.1);border-right: 1px solid #C1C3D1;"><a href=' + $scope.place.website + '>Visit Website</a></td>' +
            ' </tr>' +
            '<tr style="border-top: 1px solid #C1C3D1;border-bottom-: 1px solid #C1C3D1;color:#666B85;font-size:16px;font-weight:normal;text-shadow: 0 1px 1px rgba(256, 256, 256, 0.1);">' +
            '<td style="text-align:left;padding:20px;text-align:left;vertical-align:middle;font-weight:300;font-size:18px;text-shadow: -1px -1px 1px rgba(0, 0, 0, 0.1);border-right: 1px solid #C1C3D1;">Map Location</td>' +
            '<td style="text-align:left;padding:20px;text-align:left;vertical-align:middle;font-weight:300;font-size:18px;text-shadow: -1px -1px 1px rgba(0, 0, 0, 0.1);border-right: 1px solid #C1C3D1;"><a href=' + link + '>Map</a></td>' +
            ' </tr>' +
            '  </tbody>' +
            '  </table>' +
            '  </body>';
        writer.onwrite = function(evt) {
            console.log("write success");
        };
        writer.write(tabledata);
        window.plugins.emailComposer.showEmailComposer("Restaurant details from MapFood", emaildata, [], [], [], true, [loc]);
    }


}])

/*Convenient display of Popups*/
MapFoodControllers.factory('PopUp', function($ionicPopup, $location) {


    return {
        showAlert: function(msg) {

            var alertPopup = $ionicPopup.alert({
                title: '<span class="step size-48 "><i class="icon ion-alert-circled error"></i></span>',
                template: '<div style="text-align: center;"><span>' + msg + '</span></div>'
            });
            alertPopup.then(function(res) {
                $location.path('/');
            });
            return msg;
        },

        showSuccess: function(msg) {

            var alertPopup = $ionicPopup.alert({
                title: ' <span class="step size-48 "><i class="icon ion-thumbsup"></i></span>',
                template: '<div style="text-align: center;"><span>' + msg + '</span></div>'
            });
            alertPopup.then(function(res) {

            });
            return msg;
        }

    }
});