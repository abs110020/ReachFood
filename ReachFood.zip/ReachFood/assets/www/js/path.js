/*
 * Provides url using  $stateProvider
 */

angular.module('ReachFood', ['ionic', 'ReachFoodControllers'])

.config(['$stateProvider', '$urlRouterProvider',
    function($stateProvider, $urlRouterProvider) {

        $stateProvider
            .state('Home', {
                url: '/',
                controller: 'HomeCtrl',
                templateUrl: 'templates/home.html'
            })

        .state('RestaurantList', {
                url: '/RestaurantList/:restId',
                controller: 'RestaurantListCtrl',
                templateUrl: 'templates/showRestaurants.html'
            })
            .state('Place', {
                url: '/place/:placeId',
                controller: 'RestaurantDetailCtrl',
                templateUrl: 'templates/restaurantDetails.html'
            })

        .state('AboutApp', {
            url: '/about',
            templateUrl: 'templates/aboutApp.html'
        });

        $urlRouterProvider.otherwise("/");

    }
])

.run(function($ionicPlatform, $rootScope, $location) {

    $rootScope.Homepage = function() {
        $location.path('/');
    };

    $rootScope.AboutApp = function() {
        $location.path('/about');
    };


});