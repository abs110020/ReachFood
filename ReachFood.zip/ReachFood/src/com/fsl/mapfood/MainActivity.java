package com.fsl.mapfood;

import org.apache.cordova.DroidGap;

import com.fsl.mapfood.R;

import android.os.Bundle;
import android.view.Menu;
import android.view.MotionEvent;
import android.webkit.WebView;


public class MainActivity extends DroidGap {
	WebView mWebView;
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		super.setIntegerProperty("splashscreen", R.drawable.screen);
	//	com.adobe.mobile.Config.setContext(this.getApplicationContext());
		super.loadUrl("file:///android_asset/www/index.html",3000);
		
	}
	
	
	@Override
	public void onResume() {
		super.onResume();
		
	}
	
	@Override
	public void onPause() {
		super.onPause();
		
	}
	
	
	
	@Override
	public boolean onTouchEvent(MotionEvent event) {

	    if (event.getAction() == MotionEvent.ACTION_DOWN){

	        int temp_ScrollY = mWebView.getScrollY();
	        mWebView.scrollTo(mWebView.getScrollX(), mWebView.getScrollY() + 1);
	        mWebView.scrollTo(mWebView.getScrollX(), temp_ScrollY);

	    }

	    return super.onTouchEvent(event);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		
		
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
		
		
		
		
		
	}

}
